extends Node3D

@onready var map_spawner: MapSpawner = $MapSpawner
@onready var tile_palette: TilePalette = $CanvasLayer/TilePalette

@export var camera: Camera3D

var hovered_tile: RTSMapTile = null
var selected_tile_type: int = EnumMappings.GroundType.GRAS_TILE
var selected_height_action: float = 0.0


func _ready() -> void:
	tile_palette.save_requested.connect(_on_save_requested)
	tile_palette.reset_requested.connect(_on_reset_requested)


func _process(_delta: float) -> void:
	_update_hovered_tile()


func _on_save_requested() -> void:
	map_spawner.save_map()
	print("Map saved")


func _on_reset_requested() -> void:
	map_spawner.reset_map()


func _update_hovered_tile() -> void:
	var tile := _get_tile_under_mouse()
	_set_hovered_tile(tile)


func _get_tile_under_mouse() -> RTSMapTile:
	# Uses the same ray logic style as RTSBuildSystem/System:
	# viewport mouse position -> viewport camera/current camera -> project ray -> physics ray query.
	return GetTileUnderMouse.get_tile(
		get_viewport(),
		get_world_3d(),
		map_spawner,
		camera,
		[self],
		10000.0
	)


func _set_hovered_tile(tile: RTSMapTile) -> void:
	if hovered_tile == tile:
		return

	if hovered_tile != null:
		hovered_tile.set_hovered(false)

	hovered_tile = tile

	if hovered_tile != null:
		hovered_tile.set_hovered(true)
		
		
		
		
static func get_tile(
	viewport: Viewport,
	world_3d: World3D,
	map_spawner: MapSpawner,
	camera: Camera3D = null,
	exclude: Array = [],
	ray_length: float = DEFAULT_RAY_LENGTH,
	tile_size: float = DEFAULT_TILE_SIZE
) -> RTSMapTile:
	if map_spawner == null:
		push_error("GetTileUnderMouse: map_spawner is null.")
		return null

	var grid_pos := get_grid_position(viewport, world_3d, camera, exclude, ray_length, tile_size)
	if grid_pos == Vector2i(-1, -1):
		return null

	return map_spawner.get_tile_at_grid(grid_pos.x, grid_pos.y)


static func get_grid_position(
	viewport: Viewport,
	world_3d: World3D,
	camera: Camera3D = null,
	exclude: Array = [],
	ray_length: float = DEFAULT_RAY_LENGTH,
	tile_size: float = DEFAULT_TILE_SIZE
) -> Vector2i:
	var result := get_ray_result(viewport, world_3d, camera, exclude, ray_length)
	if result.is_empty():
		return Vector2i(-1, -1)

	var pos: Vector3 = result.get("position", Vector3.INF)
	if pos == Vector3.INF:
		return Vector2i(-1, -1)

	# IMPORTANT:
	# For tile selection, do NOT use pos.snapped(...) before calculating the tile.
	# Snapping is good for placing buildings on grid points, but for selecting a tile
	# it jumps at the tile center and can select the neighbour too early.
	var grid_x := int(floor(pos.x / tile_size))
	var grid_y := int(floor(pos.z / tile_size))

	return Vector2i(grid_x, grid_y)


static func get_snapped_position(
	viewport: Viewport,
	world_3d: World3D,
	camera: Camera3D = null,
	exclude: Array = [],
	ray_length: float = DEFAULT_RAY_LENGTH,
	grid_size: float = DEFAULT_TILE_SIZE
) -> Vector3:
	var result := get_ray_result(viewport, world_3d, camera, exclude, ray_length)
	if result.is_empty():
		return Vector3.INF

	var pos: Vector3 = result.get("position", Vector3.INF)
	if pos == Vector3.INF:
		return Vector3.INF

	return pos.snapped(Vector3(grid_size, 0.0, grid_size))


static func get_ray_result(
	viewport: Viewport,
	world_3d: World3D,
	camera: Camera3D = null,
	exclude: Array = [],
	ray_length: float = DEFAULT_RAY_LENGTH
) -> Dictionary:
	if viewport == null:
		push_error("GetTileUnderMouse: viewport is null.")
		return {}

	if world_3d == null:
		push_error("GetTileUnderMouse: world_3d is null.")
		return {}

	var used_camera := camera
	if used_camera == null:
		used_camera = viewport.get_camera_3d()

	if used_camera == null:
		push_error("GetTileUnderMouse: no Camera3D found.")
		return {}

	var mouse_pos := viewport.get_mouse_position()
	var from := used_camera.project_ray_origin(mouse_pos)
	var to := from + used_camera.project_ray_normal(mouse_pos) * ray_length

	var query := PhysicsRayQueryParameters3D.create(from, to)
	query.exclude = _clean_exclude_array(exclude)
	query.collide_with_bodies = true
	query.collide_with_areas = true

	return world_3d.direct_space_state.intersect_ray(query)


static func _clean_exclude_array(exclude: Array) -> Array:
	var cleaned: Array = []
	for item in exclude:
		if item != null:
			cleaned.append(item)
	return cleaned
