extends RefCounted
class_name GetTileUnderMouse


const DEFAULT_RAY_LENGTH: float = 10000.0


static func get_tile(viewport: Viewport, world_3d: World3D, camera: Camera3D = null, exclude: Array = [], ray_length: float = DEFAULT_RAY_LENGTH) -> RTSMapTile:
	var result := get_ray_result(viewport, world_3d, camera, exclude, ray_length)

	if result.is_empty():
		return null

	var collider: Object = result.get("collider")
	return extract_tile(collider)


static func get_ray_result(viewport: Viewport, world_3d: World3D, camera: Camera3D = null, exclude: Array = [], ray_length: float = DEFAULT_RAY_LENGTH) -> Dictionary:
	if viewport == null:
		push_error("GetTileUnderMouse: viewport is null.")
		return {}

	if world_3d == null:
		push_error("GetTileUnderMouse: world_3d is null.")
		return {}

	var used_camera := camera
	if used_camera == null:
		used_camera = viewport.get_camera_3d()

	if used_camera == null:
		push_error("GetTileUnderMouse: no Camera3D found.")
		return {}

	var mouse_pos := viewport.get_mouse_position()
	var ray_origin := used_camera.project_ray_origin(mouse_pos)
	var ray_end := ray_origin + used_camera.project_ray_normal(mouse_pos) * ray_length

	var query := PhysicsRayQueryParameters3D.create(ray_origin, ray_end)
	query.collide_with_bodies = true
	query.collide_with_areas = true
	query.exclude = _clean_exclude_array(exclude)

	return world_3d.direct_space_state.intersect_ray(query)


static func extract_tile(collider: Object) -> RTSMapTile:
	if collider == null:
		return null

	if collider is RTSMapTile:
		return collider as RTSMapTile

	if collider is Node:
		var node := collider as Node

		if node.has_meta("tile_ref"):
			var ref = node.get_meta("tile_ref")
			if ref is RTSMapTile:
				return ref

		var current: Node = node
		while current != null:
			if current is RTSMapTile:
				return current as RTSMapTile
			current = current.get_parent()

	return null


static func get_hit_position(viewport: Viewport, world_3d: World3D, camera: Camera3D = null, exclude: Array = [], ray_length: float = DEFAULT_RAY_LENGTH) -> Vector3:
	var result := get_ray_result(viewport, world_3d, camera, exclude, ray_length)

	if result.is_empty():
		return Vector3.INF

	return result.get("position", Vector3.INF)


static func _clean_exclude_array(exclude: Array) -> Array:
	var cleaned: Array = []

	for item in exclude:
		if item != null:
			cleaned.append(item)

	return cleaned
